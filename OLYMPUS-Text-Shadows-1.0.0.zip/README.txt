OLYMPUS TEXT SHADOWS
====================

Custom PvP resource pack for OLYMPUS PvP.

Style:
- Bold, clean Minecraft-friendly font
- Designed to pair with Minecraft's native text drop-shadow rendering
- Intended for nametags, chat, GUI text, scoreboards, actionbars, titles and other text
- No shader mod required

Installation:
1. Put this ZIP in .minecraft/resourcepacks.
2. Enable it in Minecraft's Resource Packs menu.
3. Keep it above other font-changing packs.

Important:
This pack changes the default Minecraft font. Minecraft's own text renderer supplies the actual dark drop shadow where that renderer supports text shadows. It does not use a fake MiniMessage <shadow> tag or require a plugin.

Made for OLYMPUS PvP / ServerBase.
